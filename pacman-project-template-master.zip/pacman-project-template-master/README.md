# UoM COMP90054 AI Planning for Autonomy - Pacman Project Templates

This repository is used by students to fork their own repository to work for the team submission.

You must FORK **privately** this repository and change slightly the name to **comp90054-2018-pacman-project-<your student number>**

Do the following commands:

